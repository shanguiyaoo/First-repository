// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

var $ = cloud.database().command.aggregate

// 云函数入口函数
exports.main = async (event, context) => {
  return cloud.database().collection("relation").aggregate()
    .march({
      tz_name: name
    })
    .lookup({
      from: "goods",
      localField: 'goods_name',
      foreignField: 'name',
      as: 'uapproval'
    })
    .lookup({
      from: "tuanzhang",
      localField: 'tz_name',
      foreignField: 'name',
      as: 'lapproval'
    })
    .replaceRoot({
      newRoot: $.mergeObjects([$.arrayElemAt(['$uapproval', 0]), $.arrayElemAt(['$lapproval', 0]), '$$ROOT'])
    })
    .project({
      uapproval: 0,
      lapproval: 0
    })
    .end({
      success: function (res) {
        return res;
        this.setData({
          list: res.data
        })
        console.log("调用云函数连表查询的返回结果",res)
      },
      fail(error) {
        return error;
      }
    })

}