//app.js
App({
  onLaunch: function () {
    //小程序一启动，就会执行
  
    console.log('小程序开始启动啦')
    wx.cloud.init({
      env: 'env-6gaor7vufd9b0012' //云开发环境ID
    })
    this.getOpenid()
    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
    // 获取用户信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: res => {
              // 可以将 res 发送给后台解码出 unionId
              this.globalData.userInfo = res.userInfo

              // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
              // 所以此处加入 callback 以防止这种情况
              if (this.userInfoReadyCallback) {
                this.userInfoReadyCallback(res)
              }
            }
          })
        }
      }
    })
  },
  globalData: {
    userInfo: null
  },
   // 获取用户openid
   getOpenid: function () {
    var app = this;
    var openidStor = wx.getStorageSync('openid');
    if (openidStor) {
      console.log('本地获取openid:' + openidStor);
      app.globalData.openid = openidStor;
      app._getMyUserInfo();
    } else {
      wx.cloud.callFunction({
        name: 'getOpenid',
        success(res) {
          console.log('云函数获取openid成功', res.result.openid)
          var openid = res.result.openid;
          wx.setStorageSync('openid', openid)
          app.globalData.openid = openid;
          app._getMyUserInfo();
        },
        fail(res) {
          console.log('云函数获取失败', res)
        }
      })
    }
  },
    //获取自己后台的user信息
    _getMyUserInfo() {
      let app = this
      var user = wx.getStorageSync('user');
      if (user) {
        console.log('本地获取user', user)
        app.globalData.userInfo = user;
      }
      wx.request({
        url: app.globalData.baseUrl + '/user/getUserInfo',
        data: {
          openid: app.globalData.openid
        },
        success: function (res) {
          console.log("", res.data)
          if (res && res.data && res.data.data) {
            app.globalData.userInfo.nickName = res.data.data.username;
            app.globalData.userInfo.realphone = res.data.data.phone;
            app.globalData.userInfo.realzhuohao = res.data.data.zhuohao;
            app.globalData.userInfo.realrenshu = res.data.data.renshu;
            console.log("===app.globalData===", app.globalData.userInfo)
            //缓存到sd卡里
            app._saveUserInfo(app.globalData.userInfo);
          }
        }
      })
    },
    _checkOpenid() {
      let app = this
      let openid = this.globalData.openid;
      if (!openid) {
        app.getOpenid();
        wx.showLoading({
          title: 'openid不能为空，请重新登录',
        })
        return null;
      } else {
        return openid;
      }
    },
  
})