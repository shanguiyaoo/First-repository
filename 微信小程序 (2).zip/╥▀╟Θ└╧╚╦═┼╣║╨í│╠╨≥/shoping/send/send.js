var id = ''
Page({
  data: {
    now_state: null,
    list: [],
  
  },
  onLoad() {
   this.getList()
  },
  getList() {
    wx.cloud.database().collection('order').where({
      status:0
    }).get()
      .then(res => {
        console.log("请求成功", res)
        this.setData({
          list: res.data
        })
      }).catch(res => {
        console.log("请求失败", res)
      })
  },
  //修改数据（使用doc）
  update(e) {
    id = this.data.id
    console.log("打印一下这里的id",id)
    wx.cloud.database().collection('order')
      .doc(id) //doc查询相应的商品ID 后进行修改
      .update({
        data: {
          status: 2
        } //只用写需要修改的属性
      })
      .then(res => {
        console.log('修改成功', res)

      })
      .catch(err => {
        console.log('修改失败', err)
      })
      this.getList()
  },



  sure: function (e) {
   
    console.log("携带的数据",e.currentTarget.dataset.id)
    let id = e.currentTarget.dataset.id
   this.setData ({
     id: id
   })
    wx.showToast({
      title: '已提醒客户！', // 标题
      icon: 'success', // 图标类型，默认success
      duration: 1800 // 提⽰窗停留时间，默认1500ms
    })
    this.update()
  },
  more: function () {
    var that = this
    that.setData({
      now_state: true
    })
    console.log(that.data.now_state);

  },
  hideModal(e) {
    //首先创建一个动画对象（让页面不在是一个“死页面”）
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation
    //animation.translateY(300)中的translate函数是表示在y轴上平移多少px，而后面紧接着的.step表示前面动画的完成，可以开始下一个动画了
    animation.translateY(300).step()
    this.setData({
      /*这里的export函数是导出动画队列，在外米的wxml中会用到该数据，同时export方法在调用完后会清掉前面的动画操作 */
      animationData: animation.export(),
    })
    /*这里的setTimeout是一个延时器，而它在这里延时了200ms，然后在执行动画 */
    setTimeout(function () {
      animation.translateY(0).step()
      this.setData({
        animationData: animation.export(),
        now_state: false,
      })
    }.bind(this), 200)
    var that = this

  },
})