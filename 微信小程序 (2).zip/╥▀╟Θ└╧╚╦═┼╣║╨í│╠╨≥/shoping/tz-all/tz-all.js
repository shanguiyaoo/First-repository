var id = ''
Page({
  data: {
    now_state: null,
    id: ''
  },
  onLoad() {
    this.getList()
  },
  // 删除数据 （doc
  remove() {
    let id = this.data.id
    console.log("点击了删除", id)
    wx.cloud.database().collection('order')
      .doc(id) //doc查询相应的商品ID 后进行删除
      .remove({

      })
      .then(res => {
        console.log('删除成功', res)
        this.getList()
      })
      .catch(err => {
        console.log('删除失败', err)
      })
  },

  //请求数据
  getList() {
    //请求当前用户名替换“八戒”
    let db = wx.cloud.database()
    const _ = db.command //   _ 可以随意替换成其他名字
    db.collection('orders')
      .where(
        _.or([{
            name: "八戒"
          },
          {
            status: 0
          }
        ])
      )
      .get()
      .then(res => {
        console.log("请求成功", res)
        this.setData({
          list: res.data
        })
      }).catch(res => {
        console.log("请求失败", res)
      })
  },
  sure: function (e) {
    var that = this
    that.setData({
      now_state: true
    })
    this.setData({
      id: e.currentTarget.dataset.id
    })
    console.log(that.data.now_state);

  },
  hideModal(e) {
    //首先创建一个动画对象（让页面不在是一个“死页面”）
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation
    //animation.translateY(300)中的translate函数是表示在y轴上平移多少px，而后面紧接着的.step表示前面动画的完成，可以开始下一个动画了
    animation.translateY(300).step()
    this.setData({
      /*这里的export函数是导出动画队列，在外米的wxml中会用到该数据，同时export方法在调用完后会清掉前面的动画操作 */
      animationData: animation.export(),
    })
    /*这里的setTimeout是一个延时器，而它在这里延时了200ms，然后在执行动画 */
    setTimeout(function () {
      animation.translateY(0).step()
      this.setData({
        animationData: animation.export(),
        now_state: false,
      })
    }.bind(this), 200)
    var that = this

  },
  ok: function () {
    this.remove()
    wx.showToast({
      title: '操作成功！', // 标题
      icon: 'success', // 图标类型，默认success
      duration: 1800 // 提⽰窗停留时间，默认1500ms
    })
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation
    //animation.translateY(300)中的translate函数是表示在y轴上平移多少px，而后面紧接着的.step表示前面动画的完成，可以开始下一个动画了
    animation.translateY(300).step()
    this.setData({
      /*这里的export函数是导出动画队列，在外米的wxml中会用到该数据，同时export方法在调用完后会清掉前面的动画操作 */
      animationData: animation.export(),
    })
    /*这里的setTimeout是一个延时器，而它在这里延时了200ms，然后在执行动画 */
    setTimeout(function () {
      animation.translateY(0).step()
      this.setData({
        animationData: animation.export(),
        now_state: false,
      })
    }.bind(this), 200)
    var that = this

  }
})