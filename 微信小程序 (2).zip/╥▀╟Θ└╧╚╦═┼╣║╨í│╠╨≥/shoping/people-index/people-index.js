// pages/people-index/people-index.ts
let name = ""
let num = ""
let price = ""
var id = ""
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: [],
    change: true
  },
  //点击按钮跳转页⾯


  onLoad: function () {
    this.getList()
  },
  getList() {
    wx.cloud.database().collection('goods').get()
      .then(res => {
        console.log("请求成功", res)
        this.setData({
          list:res.data
        })
      }).catch(res => {
        console.log("请求失败", res)
      })

  },
  //获取用户输入的商品名
  getName(e) {
    name = e.detail.value
    console.log("新输入的商品名", name)
  },
  //获取用户输入的新价格 
  getPrice(e) {
    price = e.detail.value
    console.log("新输入的价格", price)
  },
  //获取用户输入的新数量 
  getNum(e) {
    num = e.detail.value
    console.log("新输入的商品数 ", num)
  },

  mmmm(e) {
    console.log('获取到商品id', e.currentTarget.dataset.id)
    id = e.currentTarget.dataset.id
    console.log(id)
    this.getDetail()
  },
  /**
   * 生命周期函数--监听页面加载
   */
  amend: function () {
    console.log("点击成功");
    this.setData({
      change: false
    })
  },
  close: function () {
    console.log("已关闭");
    this.setData({
      change: true
    })
  },
  listenFormSubmit: function (e) {
    console.log("发生了submit事件", e.detail.value);
  },
  listenFormResert: function (e) {
    console.log("发生了resert事件");
  },
  //获取商品数据
  getDetail() {

    wx.cloud.database().collection('goods') //从数据库中获取goods数据表
      .doc(id)
      .get()
      .then(res => { //请求成功
        console.log('商品列表请求成功', res)
        this.setData({
          good: res.data //将获取到的res的值赋给good
        })
      })
      .catch(res => { // 请求失败
        console.log('商品列表请求失败', res)
      })
  },
  update() {
    console.log("新的商品名", name)
    console.log("新的商品数量", num)
    console.log("新的商品价格", price)
    if (name == "") {
      wx.showToast({
        icon: "none",
        title: '商品名为空了',
      })
      return
    }
    if (num == "") {
      wx.showToast({
        icon: "none",
        title: '数量为空了',
      })
      return
    }
    if (price == "") {
      wx.showToast({
        icon: "none",
        title: '价格为空了',
      })
      return
    }

    //调用云函数更新商品价格
    wx.cloud.callFunction({
      name: 'update',
      data: {

        id: id,
        name: name,
        num: num,
        price: parseInt(price)
      }
    }).then(res => {
      console.log("云函数调用成功", res)
      this.getList()
      wx.showToast({
        title: '修改成功！',
      })
      this.getDetail()
    }).catch(res => {
      console.log("云函数调用失败", res)
    })
  }


})