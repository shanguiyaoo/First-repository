Page({
  data: {
    src: '',
    list: [],
    list2: []
  },
  back: function () {

  },
  previewImage: function () {
    var that = this
    wx.previewImage({
      urls: [this.data.src],
    })
  },
  onLoad() {
    this.getList()
    // this.getList2()
  },
  getList() {
    // const db = wx.cloud.database()
    // const _ = db.command
    // db.collection('order').where(_.and([{
    //   tz_name : "八戒",
    //   }, {
    //     status: 2
    //   }])).get()

    wx.cloud.database().collection('tuikuan')
      .where({
        status: 0
      })
      .get()


      // let db = wx.cloud.database()
      // const _ = db.command //   _ 可以随意替换成其他名字
      // db.collection('tuikuan')
      //   .where(_.and([{
      //     tz_name : "八戒",
      //     }, 
      //     {
      //       status: 1
      //     }
      //   ]))
      // .get()

      .then(res => {
        console.log("请求成功", res)
        this.setData({
          list: res.data
        })
      }).catch(res => {
        console.log("请求失败", res)
      })

  },
  // getList2() {

  //   wx.cloud.database().collection('goods').get()
  //     .then(res => {
  //       console.log("请求成功", res)
  //       this.setData({
  //         list2: res.data
  //       })
  //     }).catch(res => {
  //       console.log("请求失败", res)
  //     })
  // }
  // //点击退款后删除该条退款记录
  // remove(e) {
  //   let id = e.currentTarget.dataset.id
  //   console.log("点击退款后所传递的参数订单号", id)
  //   wx.cloud.database().collection('tuikuan')
  //     .doc(id) //doc查询相应的商品ID 后进行删除
  //     .remove({

  //     })
  //     .then(res => {
  //       console.log('删除成功', res)
  //       this.getList()
  //     })
  //     .catch(err => {
  //       console.log('删除失败', err)
  //     })
  // },




  // // update() {
  // //     let id = this.data.id
  // //     console.log("传递到update的id值", id);
  // //     wx.cloud.database().collection('tuuikuan')
  // //       .doc(id) //doc查询相应的商品ID 后进行修改
  // //       .update({
  // //         data: {
  // //           status: 0
  // //         } //只用写需要修改的属性
  // //       })
  // //       .then(res => {
  // //         console.log('修改成功', res)

  // //       })
  // //       .catch(err => {
  // //         console.log('修改失败', err)
  // //       })
  // //   },
  update(e) {
    let id = e.currentTarget.dataset.id
    console.log("所传递的id值", e.currentTarget.dataset.id)
    wx.cloud.database().collection('tuikuan')
      .doc(id) //doc查询相应的商品ID 后进行修改
      .update({
        data: {
          status: 1
        } //只用写需要修改的属性
      })
      .then(res => {
        console.log('修改成功', res)
     
      })
      .catch(err => {
        console.log('修改失败', err)
      })
    wx.cloud.database().collection('order')
      .doc(id) //doc查询相应的商品ID 后进行修改
      .update({
        data: {
          status: -1
        } //只用写需要修改的属性
      })
      .then(res => {
        console.log('修改成功', res)

      })
      .catch(err => {
        console.log('修改失败', err)
      })
      // wx.showToast({
      //   title: '支付成功！',
      // })
    this.getList()
  }

})