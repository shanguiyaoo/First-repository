let app = getApp();
const db = wx.cloud.database()
Page({
  data: { //页面的初始数据   
    isShowMyAddress: false, //是否显示我的地址
    isShowAddressSetting: false, //授权失败再次授权的弹窗
    beizhu: "", // 备注信息
    payWayList: [ {
      "id": 2,
      "package": "微信支付"
    }, {
      "id": 3,
      "package": "银行卡支付"
    }],
    cartList: [], // 购物车数据
    totalPrice: 0, //总价
    totalNum: 0, //总数量
    maskFlag: true, // 遮罩
    chief: [],
    address: [],
    list: [],
    name:''
  },
  onLoad(options) {
    this.getAddress()
    console.log("列表携带的值", options)
    let name = options
    //获取团长信息
    wx.cloud.database().collection('tuanzhang')
      .where({
        name: "八戒"
      })
      .get()
      .then(res => {
        console.log("请求成功", res)
        this.setData({
          list: res.data
        })
      }).catch(res => {
        console.log("请求失败", res)
      })
    // if (app.globalData.tuanzhang && app.globalData.tuanzhang.name) {
    //   this.setData({
    //     chief: app.globalData.tuanzhang
    //   })
    // }
    // //获取缓存地址


    // this.getAddress(wx.getStorageSync('address'))

    //购物车的数据
    var arr = wx.getStorageSync('cart') || [];
    for (var i in arr) {
      this.data.totalPrice += arr[i].quantity * arr[i].price;
      this.data.totalNum += arr[i].quantity
    }
    this.setData({
      cartList: arr,
      totalPrice: this.data.totalPrice.toFixed(2),
      totalNum: this.data.totalNum
    })
  },

  // 获取备注信息
  // getRemark(e) {
  //   this.setData({
  //     beizhu: e.detail.value
  //   })
  // },
  getAddress() {

    wx.cloud.database().collection('members')
      .where({
        status:1
      })
      .get()
      .then(res => {
        console.log("请求成功", res)
        this.setData({
          address: res.data,
        })


      }).catch(res => {
        console.log("请求失败", res)

      })
  },



  //打开支付方式弹窗
  choosePayWay() {
    var that = this;

    // 支付方式打开动画
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: 'ease-in-out',
      delay: 0
    });
    that.animation = animation;
    animation.translate(0, -285).step();
    that.setData({
      animationData: that.animation.export(),
    });
    that.setData({
      maskFlag: false,
    });
  },
  // 支付方式关闭方法
  closePayWay() {
    var that = this
    // 支付方式关闭动画
    that.animation.translate(0, 285).step();
    that.setData({
      animationData: that.animation.export()
    });
    that.setData({
      maskFlag: true
    });
  },


  //提交订单
  submitOrder(e) {
    let chief = this.data.chief
    let address = this.data.address
    // if (!chief) {
    //   app.showErrorToastUtils('请先去个人中心选择团长');
    //   return
    // }
    // if (!address || !address.address) {
    //   app.showErrorToastUtils('请选择收货地址');
    //   return
    // }
    let arr = wx.getStorageSync('cart') || [];
    let arrNew = []
    arr.forEach(item => {
      arrNew.push({
        _id: item._id,
        // chiefId: chief._id, //团长id
        name: item.name,
        price: item.price,
        quantity: item.quantity,
        img: item.img,
        chiefName:""
      })
    });
    address = this.data.address
    //由于目前不存在店铺这一说，所以一样商品单独算一个订单
    let proArr = []
    let goods = []
  console.log("订单表的团长名字",this.data.list[0])
    console.log("订单表生成的地址",this.data.address[0].address+this.data.address[0].address_detail)
    arrNew.forEach(item => {
      let pro = db.collection("order").add({
        data: {
          chiefName:this.data.list[0].name,
          name: "小时",
          address: this.data.address[0].address+this.data.address[0].address_detail,
          // phone: address.phone,
          // beizhu: this.data.beizhu,
          totalPrice: item.quantity * item.price, //总价钱
          chiefId: this.data.list[0]._id,
          // chiefXiaoqu: chief.xiaoqu,
          // pickupAddress: chief.pickupAddress,
          good: item, //存json字符串
          img: item.img,
    
          //-1订单取消,0新下单待发货,1已发货待领取，2已领取待评价,3订单已完成
          status: 2,
          // _createTime: db.serverDate() //创建的时间
          _createTime: new Date().getTime() //创建的时间
        }
      })
      proArr.push(pro)
      goods.push({
        _id: item._id,
        quantity: -item.quantity
      })
    })

    Promise.all(proArr).then(res => {
      console.log("支付成功", res)
      // 支付方式关闭动画
      this.animation.translate(0, 285).step();
      this.setData({
        animationData: this.animation.export()
      });
      this.setData({
        maskFlag: true
      });
      wx.showToast({
        title: '下单成功！',
      })
      // this.add()
      //支付成功后，把商品数量减少对应个数
      wx.cloud.callFunction({
        name: "addXiaoLiang",
        data: {
          goods: goods
        }
      }).then(res => {
        console.log('添加销量成功', res)
        wx.setStorageSync('cart', "")
        wx.switchTab({
          url: '../../pages/compete/compete',
        })
      }).catch(res => {
        console.log('添加销量失败', res)
        wx.showToast({
          icon: 'none',
          title: '支付失败',
        })
      })

    }).catch(res => {
      wx.showToast({
        icon: 'none',
        title: '支付失败',
      })
      console.log("支付失败", res)
    })
  },
  // // 管理收获地址
  // addAdress() {
  //   wx.chooseAddress({
  //     success: res => {
  //       console.log(res)
  //       app._saveAddress(res);
  //       this.getAddress(res)
  //     },
  //     //现在获取地址，不需要授权了
  //     fail: res => {
  //       console.log("获取地址失败", res)
  //       app.showErrorToastUtils('您取消了操作!，请重新获取地址');

  //     }
  //   })

  // },

  // getAddress(addressStro) {
  //   if (addressStro) {
  //     var address = app._getAddress(addressStro);
  //     var city = app._getCity(addressStro);
  //     console.log(city);
  //     if (address) {
  //       this.setData({
  //         isShowMyAddress: true,
  //         address: {
  //           userName: addressStro.userName,
  //           phone: addressStro.telNumber,
  //           city: city,
  //           address: address
  //         },
  //       })
  //     }
  //   }
  // }
  // add() {
  //   let tz_name = this.data.list.name
  //   console.log("填入订单表的团长信息", tz_name)
  //   wx.cloud.database().collection('goods')
  //     .add({ //添加数据
  //       data: {
  //         name: address.userName,
  //         address: address.address,
  //         // phone: address.phone,
  //         // beizhu: this.data.beizhu,
  //         // totalPrice: item.quantity * item.price, //总价钱
  //         // chiefId: chief._id,
  //         // chiefName: chief.name,
  //         // chiefXiaoqu: chief.xiaoqu,
  //         // pickupAddress: chief.pickupAddress,
  //         // good: item, //存json字符串
  //         // //-1订单取消,0新下单待发货,1已发货待领取，2已领取待评价,3订单已完成
  //         status: 0,
  //         // // _createTime: db.serverDate() //创建的时间
  //         // _createTime: new Date().getTime() //创建的时间

  //       }
  //     })
  //     .then(res => {
  //       console.log('添加成功', res)

  //     })
  //     .catch(err => {
  //       console.log('添加失败', err)
  //     })
  // },


})