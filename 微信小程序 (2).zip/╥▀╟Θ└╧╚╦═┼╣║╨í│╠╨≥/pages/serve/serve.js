Page({
  data: {

    list: [],
    tuikuan:[]

  },
  onLoad() {
    this.getList()
    // this.getReason()
  },
  getList() {
    wx.cloud.database().collection('tuikuan')
      .where({
        status: 1
      })
      .get()
      .then(res => {
        console.log("请求成功", res)
        this.setData({
          list: res.data
        })
      }).catch(res => {
        console.log("请求失败", res)
      })
  },
  getReason() {
    // wx.cloud.database().collection('tuikuan')
    // .where({
    //   status: 0
    // })
    // .get()
    // .then(res => {
    //   console.log("请求成功", res)
    //   this.setData({
    //     tuikuan: res.data
    //   })
    // }).catch(res => {
    //   console.log("请求失败", res)
    // })
  }

})