// pages/buy-index/buy-index.ts

//获取数据库
// const db = wx.cloud.database()
// console.log(db)
//获取集合
// const people = db.collection('people')
// const goods = db.collection('goods')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    name: '',
    people: [],
    goods: [],
    list: [],
    detailHidden: true,
    people_name: ['悟空', '八戒'], //团长的名字
    people_meun: ['hhh', 'lll'], //团长的菜品
    now_state: null

  },
 
 
  onLoad(options) {
    console.log("列表携带的值", options)
    wx.cloud.database().collection('goods').get()
      .then(res => {
        console.log("请求成功", res)
        this.setData({
          list: res.data //将获取到的res的值赋给good
        })
      }).catch(res => {
        console.log("请求失败", res)
      })
    wx.cloud.database().collection('tuanzhang').get()
      .then(res => {
        console.log("请求成功", res)
        this.setData({
          people: res.data //将获取到的res的值赋给good
        })
      }).catch(res => {
        console.log("请求失败", res)
      })
  },

  onShow: function () {
    if (typeof this.getTabBar === 'function' &&
      this.getTabBar()) {
      this.getTabBar().setData({
        selected: 0
      })
    }
  },
  onTabBar() {
    wx.redirectTo({
      url: '/shoping/people-index/people-index',
    })
  },


  IsDetailHidden: function () {
    var that = this
    that.setData({
      now_state: true
    })
    console.log(that.data.now_state);
    this.setData({
      detailHidden: !this.data.detailHidden
    })

  },
  hideModal(e) {
    //首先创建一个动画对象（让页面不在是一个“死页面”）
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation
    //animation.translateY(300)中的translate函数是表示在y轴上平移多少px，而后面紧接着的.step表示前面动画的完成，可以开始下一个动画了
    animation.translateY(300).step()
    this.setData({
      /*这里的export函数是导出动画队列，在外米的wxml中会用到该数据，同时export方法在调用完后会清掉前面的动画操作 */
      animationData: animation.export(),
    })
    /*这里的setTimeout是一个延时器，而它在这里延时了200ms，然后在执行动画 */
    setTimeout(function () {
      animation.translateY(0).step()
      this.setData({
        animationData: animation.export(),
        now_state: false,
      })
    }.bind(this), 200)
    var that = this

  },
  ok: function () {

    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation
    //animation.translateY(300)中的translate函数是表示在y轴上平移多少px，而后面紧接着的.step表示前面动画的完成，可以开始下一个动画了
    animation.translateY(300).step()
    this.setData({
      /*这里的export函数是导出动画队列，在外米的wxml中会用到该数据，同时export方法在调用完后会清掉前面的动画操作 */
      animationData: animation.export(),
    })
    /*这里的setTimeout是一个延时器，而它在这里延时了200ms，然后在执行动画 */
    setTimeout(function () {
      animation.translateY(0).step()
      this.setData({
        animationData: animation.export(),
        now_state: false,
      })
    }.bind(this), 200)
    var that = this
  },
  ChoiceFood: function (e) {
    let name = e.currentTarget.dataset.name
    console.log("点击加购后所传递的参数", name)
  
    wx.navigateTo({
      url: '../buy-food/buy-food?name=' + e.currentTarget.dataset.name
    })
  },
  cancel: function () {
    console.log("abc");

    this.setData({
      detailHidden: true
    })
  },
  // 连表查询获取团长的商品信息
  // 请求当前用户名替换“八戒”
  getList() {
    //调用云函数
    wx.cloud.callFunction({
        name: "search",
      })
      .then(res => {
        console.log("请求成功", res)
        this.setData({
          openid: res.result.openid
        })
      })
      .catch(res => {
        console.log("请求失败", res)
      })
    //     function getfavlist(event, context) {
    //       return new Promise(function (resolve, reject) {
    //     wx.cloud.database().collection('relation')
    //     .march({
    //       tz_name: "八戒"
    //     })
    //     .aggregate().lookup({
    //       from:'goods',
    //       localField: 'name',
    //       foreignField:'goods_name',
    //        as:'userInfo'
    //     }).lookup({
    //       from:'tuanzhang',
    //       localField: 'name',
    //       foreignField:'tz_name',
    //        as:'groupInfo'
    //     })
    //     .end()
    //     .then(res => {
    //       console.log("查询成功",res);
    //       resolve(res);
    //     })
    //     .catch(err => console.error(err))
    // })
    // }

    //   //  .get()
    //   //   .then(res => {
    //   //     console.log("请求成功", res.data)
    //   //     this.setData({
    //   //       list: res.data,

    //   //     })
    //   //   }).catch(res => {
    //   //     console.log("请求失败", res)
    //   //   })
  },




  // //加载列表数据
  // async loadListData(){
  //     let res1 = await people.get()
  //     let res2 = await goods.get()
  //     console.log("列表",res1)
  //     console.log("商品",res2)
  //     this.setData({
  //         people:res1.data,
  //         goods:res2.data
  //     })
  // },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})