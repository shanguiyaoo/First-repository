Page({
  data: {
    inputname: '',
    inputphone: '',
    inputid: '',
    Inputadd: ''

  },

  bindKeyInput: function (e) {
    this.setData({
      inputname: e.detail.value
    })
    console.log(e.detail.value)
  },
  Inputphone: function (e) {
    this.setData({
      inputphone: e.detail.value
    })
    console.log(e.detail.value)
  },
  InputId: function (e) {
    this.setData({
      inputid: e.detail.value
    })
    console.log(e.detail.value)
  },
  Inputadd: function (e) {
    this.setData({
      Inputadd: e.detail.value
    })
    console.log(e.detail.value)
  },
  submit: function () {
    let name = this.data.inputname
    let phoneNum = this.data.inputphone
    let ID_card = this.data.inputid
    let community = this.data.Inputadd
    wx.cloud.database().collection('tuanzhang').add({
      data: {
        name: name,
        phone: phoneNum,
        ID_card: ID_card,
        community: community
      },
      success(res) {
        console.log("注册成功", res)
        wx.showToast({
          title: '申请成功！', // 标题
          icon: 'success', // 图标类型，默认success
          duration: 1800 // 提⽰窗停留时间，默认1500ms
        })
      },
      fail(res) {
        console.log("注册失败", console.res)
      }
    })

    setTimeout(function () {
      wx.redirectTo({
        url: '../../shoping/people-index/people-index'
      })
    }, 2000)

  },
})