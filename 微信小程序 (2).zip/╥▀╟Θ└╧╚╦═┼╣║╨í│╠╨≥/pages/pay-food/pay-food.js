// pages/pay-food/pay-food.ts
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: [],
    cartList: [],
  },
  //获取购物车缓存数据
  getCartList() {
    console.log("本地缓存的购物车数据", cartList)
  },
  pay: function () {
    wx.navigateTo({
      url: "../pay/pay"
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {
    // let db = wx.cloud.database()
    // const $ = db.command.aggregate
    // const _ = db.command //   _ 可以随意替换成其他名字
    // db.collection('order_detail')
    //   .where({

    //     num: _.gte(0), //查询数量大于10
    //   })

    //   .get()

    //   .then(res => {
    //     console.log("成功", res)
    //     this.setData({
    //       list: res.data
    //     })
    //   })
    //   .catch(res => {
    //     console.log("失败", res)
    //   })
    // this.quchong()
  },
  // quchong(e) {
  //   let db = wx.cloud.database()
  //   const $ = db.command.aggregate
  //   db.collection('order_detail').aggregate()
  //     .group({
  //       _id: '',
  //       uniqueValues: $.addToSet('$name')
  //     })
  //     .end()    
  //     .then(res => {
  //       console.log("成功", res)
  //       this.setData({
  //         list: res.data
  //       })
  //     })
  //     .catch(res => {
  //       console.log("失败", res)
  //     })
  //     // this.setData({
  //     //   listcart: list
  //     // })
  // }
})