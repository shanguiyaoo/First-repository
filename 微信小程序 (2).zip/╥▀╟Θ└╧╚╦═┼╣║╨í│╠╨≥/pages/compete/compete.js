Page({

  /**
   * 页面的初始数据
   */
  data: {
    triggered: false,
    userInfo: null,
    address: '',
    mmm: '',
    status: '',
    src:'',
    // checkboxItems: [{
    //   name: "（湖南省长沙市岳麓区咸嘉湖街道湖南工商大学）",
    //   value: "add1"
    // }],
    list: ''
  },
  onScrollRefresh: function () {
    var that=this;
    setTimeout(function(){
      that.setData({
        triggered: false,
      })
    },2000);
    this.getList()
  },

  getDetail(e) {
    console.log("选择地址后所返回的值", e)
  },
  getStatus(e) {
    // console.log("选择地址后所返回的值", e)
  },

  onLoad(options) {
    this.getList()
      let user=wx.getStorageSync('user')
      console.log('进入小程序的页面获取缓存',user.nickName)
      console.log('进入小程序的页面获取缓存',user.avatarUrl)
      this.setData({
        userInfo:user.nickName,
        scr:user.avatarUrl
      })
      
  },
  //  //监听用户下拉动作
  //  onPullDownRefresh: function () {
  //   this.getList()
  // },
  getList(isPull) {
    wx.cloud.database().collection('members').get()
      .then(res => {
        console.log("请求成功", res)
        if (isPull) {
          wx.stopPullDownRefresh({
            success: (res) => {},
          })
        }
        this.setData({
          list: res.data
        })
      }).catch(res => {
        console.log("请求失败", res)
      })
  },

  all: function () {
    wx.navigateTo({
      url: '../all/all',
    })
  },
  wait: function () {
    wx.navigateTo({
      url: '../receive/receive',
    })
  },
  back: function () {
    wx.navigateTo({
      url: '../serve/serve',
    })
  },
  change: function (e) {

    let mmm = e.detail.value
    console.log("这里：" + e.detail.value);
    const db = wx.cloud.database()
    db.collection('members')
      .where({
        
        address_detail: mmm
      })
      .update({
        data: {
          status: 1
        }

      })

    const _ = db.command
    db.collection('members')
    .where({
        address_detail: _.not(_.eq(mmm))
      })
      .update({
        data: {
          status: 0
        }
      })
    //   })
    console.log("translate", e)


  },
  address: function () {
    wx.navigateTo({
      url: '../address/add',
    })
  },
  // checkboxchange:function(e){
  //   var that= this;
  //   let checkboxValues=null;
  //   let checkboxItems = this.data.checkboxItems,values=e.detail.values
  //   for (var i = 0, lenI = checkboxItems.length; i < lenI; ++i) {
  //     if(checkboxItems[i].value==values[values.length-1]){
  //       checkboxItems[i].checked=true;
  //       checkboxValues = checkboxItems[i].value;
  //     }
  //     else{
  //       checkboxItems[i].checked = false;
  //     }
  //   }
  //   console.log(checkboxValues)
  //   that.setData({ checkboxItems, checkboxValues })
  // }


})